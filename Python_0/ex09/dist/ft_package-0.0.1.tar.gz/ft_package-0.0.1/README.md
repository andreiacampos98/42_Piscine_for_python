# ft_package

This is a sample test package for learning Python packaging.  
It includes a simple function `count_in_list`.

```python
from ft_package import count_in_list

print(count_in_list(["toto", "tata", "toto"], "toto"))  # 2