from setuptools import setup

# Essa função lê as informações da configuração \
# (geralmente de setup.cfg e/ou pyproject.toml) \
# e prepara o pacote para ser instalado com pip.
setup()
